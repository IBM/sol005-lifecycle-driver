#!/bin/sh
# Install script
echo Beginning install